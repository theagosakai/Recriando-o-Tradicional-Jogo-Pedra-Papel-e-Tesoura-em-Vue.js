#  🌑Pedra, 📄Papel e ✂️Tesoura!

## Feito por [👨‍💻João Pedro Resende🚀](https://jpres.dev)
## Desafio
Desafio do [Frontend-Mentor.io](https://www.frontendmentor.io/)

[clique aqui para ir para o desafio](https://www.frontendmentor.io/challenges/rock-paper-scissors-game-pTgwgvgH)
## Apresentação📄

Feito em live na [twitch.tv/jpbrab0](https://twitch.tv/jpbrab0). E utilizando conceitos basicos da programação como:

* Lógica Basica
* Váriaveis
* Constantes
* Funções
* Estruturas condicionais
* DOM

## Projeto
Caso você queira ver como ficou o projeto [**clique aqui**](https://jpbrab0.github.io/pedra-papel-tesoura/)😉

## Tecnologias💻
* Html
* Css
* Js

## Contribuição
Caso você queira contribuir com o projeto deixa uma estrela e compartilhe para ver mais projetos como este!😁

### **Feito para estudo e diversão!!!**
